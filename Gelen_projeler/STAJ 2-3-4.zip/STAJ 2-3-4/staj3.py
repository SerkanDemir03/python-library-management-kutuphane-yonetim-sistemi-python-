# Kitap listesi
kitaplar = []

while True:
    print("\n--- Kütüphane Sistemi ---")
    print("1- Kitap ekle")
    print("2- Kitap sil")
    print("3- Kitapları listele")
    print("4- Kitap ara")
    print("5- Kitap sayısını bul (count YOK)")
    print("6- Alfabetik sırala")
    print("7- Listeyi ters çevir")
    print("8- Kitabın indeksini bul")
    print("9- Listeyi kopyala")
    print("10- Listeyi temizle")
    print("11- Liste boş mu kontrol et (all/any)")
    print("0- Çıkış")

    secim = input("Seçiminiz: ")

    if secim == "1":
        kitap = input("Eklemek istediğiniz kitabı girin: ")
        kitaplar.append(kitap)
        print("Kitap eklendi!")
    elif secim == "2":
        kitap = input("Silmek istediğiniz kitabı girin: ")
        if kitap in kitaplar:
            kitaplar.remove(kitap)
            print("Kitap silindi!")
        else:
            print("Kitap bulunamadı.")
    elif secim == "3":
        print("Kütüphane:", kitaplar)
    elif secim == "4":
        kitap = input("Aranan kitap: ")
        if kitap in kitaplar:
            print(f"{kitap} listede var!")
        else:
            print(f"{kitap} listede yok!")
    elif secim == "5":
        kitap = input("Hangi kitabın tekrar sayısı?: ")
        sayac = 0
        for k in kitaplar:  
            if k == kitap:
                sayac += 1
        print(f"{kitap} listede {sayac} kez var.")
    elif secim == "6":
        kitaplar.sort()
        print("Alfabetik sıralandı:", kitaplar)
    elif secim == "7":
        kitaplar.reverse()
        print("Liste ters çevrildi:", kitaplar)
    elif secim == "8":
        kitap = input("İndeksini öğrenmek istediğiniz kitap: ")
        if kitap in kitaplar:
            print(f"{kitap} indeks: {kitaplar.index(kitap)}")
        else:
            print("Kitap bulunamadı.")
    elif secim == "9":
        yeni = kitaplar.copy()
        print("Liste kopyalandı:", yeni)
    elif secim == "10":
        kitaplar.clear()
        print("Liste temizlendi!")
    elif secim == "11":
        if any(kitaplar):
            print("Listede en az bir kitap var.")
        else:
            print("Liste tamamen boş.")
    elif secim == "0":
        print("Programdan çıkılıyor...")
        break
    else:
        print("Geçersiz seçim!")
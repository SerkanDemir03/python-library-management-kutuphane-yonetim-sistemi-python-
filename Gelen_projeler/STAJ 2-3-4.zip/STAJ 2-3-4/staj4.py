#MIXED LIST
"""
mixed_list = [1,2,3,"emrecan",True,False,None,[1,2,3],(1,2,3)]
print(mixed_list)

print(mixed_list[0]) # 1
print(mixed_list[7][1])

print(mixed_list.append([1,3,4,5,6,7,8,9,10]))
print(mixed_list)
#NESTED LIST > MATRIS
"""

nested_list = [
    #0 #1 #2
    [1,2,3], #0
    [4,5,6], #1
    [7,8,9], #2 
    [[10,11,12],[13,14,15]] #3
]
"""        #0       #1
print(nested_list)
print(nested_list[0][1])
print(nested_list[3][0][1]) #11


#for elaman in nested_list:
    #print(elaman)
for elaman in nested_list:
    x = nested_list[3][1]
    if elaman == x:
        print(elaman)
        continue
    else:
        break
"""
"""
#TUPLE
tuple_list = (1,2,3)
print(tuple_list)
print(type(tuple_list))

tuple2_list = (1,)
print(tuple2_list)
print(type(tuple2_list))

tuple3_list = (2)
print(tuple3_list)
print(type(tuple3_list))

numbers = (1,2,3,4)
print(numbers[0])  #1
mixed_tuple = ([1,2,3],(6,7,8))
print(mixed_tuple)
print(mixed_tuple[0].insert(4,5))
print(mixed_tuple)
print(type(mixed_tuple))

"""
"""
#TUPLE METHODS
numbers = (1,2,3,4,5,6,7,8,9,10,5,5,5,5)
print(numbers.count(5))
print(numbers.index(5))
"""

#MATH
import math
print(math.pi) 
print(math.sqrt(16))
print(math.pow(2,3))
print(2**3) #2 üzeri 3
print(math.floor(3.9)) #aşşağıya yuvarlıyor
print(math.ceil(3.2)) # yukarıya yuvarlıyor.
print(math.factorial(5))
print(math.fabs(-10))    #MUTLAK DEGER

from math import sqrt,pi
print(sqrt(16))
print(pi)

#Öğrenci Not ve İstatistik Sistemi
"""
Proje Adımları

Kullanıcıdan öğrenci sayısını al.
Her öğrenci için:
Adı ve soyadı (string)
Yaşı (int)
Notlarını al (tuple veya list)
Tüm öğrencileri nested list içinde sakla.
Her öğrenci için:
Ortalama, maksimum, minimum notları hesapla.
Tüm öğrenciler için genel istatistikleri göster:
En yüksek ortalama #max
En düşük ortalama #min
"""




